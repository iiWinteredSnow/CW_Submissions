import java.util.Scanner;
public class Typeinconsole {

	public static void main(String[] args) {
		Scanner myReader = new Scanner(System.in);
		System.out.print("your input is" + myReader.nextLine());
		myReader.close();

	}

}
