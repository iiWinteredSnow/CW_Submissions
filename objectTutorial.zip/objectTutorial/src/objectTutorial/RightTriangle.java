package objectTutorial;

public class RightTriangle {
	private double oppo;
	private double adja;
	private double hyp;
	static int dimensions = 2;
	
	public RightTriangle(double opp, double adj) 
	{
		hyp = Math.sqrt((opp*opp)+(adj*adj));
		oppo = opp;
		adja = adj;
	}
	public double getHyp()
	{
		return hyp;
	}
	public double getArea() 
	{
		return (oppo*adja)*.5;
	}
	public double getPerimeter()
	{
		return hyp+oppo+adja;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
