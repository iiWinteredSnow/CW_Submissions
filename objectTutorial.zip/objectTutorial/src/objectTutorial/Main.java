package objectTutorial;

public class Main {

	public static void main(String[] args) {
		
		RightTriangle triOne = new RightTriangle(3.0, 4.0);
		System.out.println(triOne.getArea());
		System.out.println(triOne.getHyp());
		System.out.println(triOne.getPerimeter());
		
		Circle circOne = new Circle(3.0);
		Circle circTwo = new Circle(20.0);
		Circle circThree = new Circle(-4.0);
		System.out.println(circOne.getRadius());
		System.out.println(circTwo.getRadius());
		System.out.println(circThree.getRadius());
		System.out.println(circOne.getShape());
		System.out.println(circOne.getDiameter());
		//System.out.println(Circle.getShape());  // this will be an error.
	}

}
