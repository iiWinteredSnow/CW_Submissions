package objectTutorial;

public class Circle {
	//data attributes
		final double pi = 3.14159265;
		private double radius;
		static int dimensions = 2;
		
		public Circle(double r) {
			radius  = r;
			
		}
	// functionality
		public double getRadius() {
			return radius;
		}
		public String getShape() {
			return "Circle";
		}
		public double getDiameter() {
			return radius*2;
		}
}